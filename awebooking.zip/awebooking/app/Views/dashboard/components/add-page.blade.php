<a class="btn btn-success waves-effect waves-light" href="{{ url('dashboard/add-new-page')  }}">
    <i class="ti-plus mr-1"></i>
    {{ __('Create New') }}
</a>